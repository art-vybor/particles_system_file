#include <windows.h>
#include <GL/gl.h>
#include "GL/glut.h"
#include <string.h>
#include <stdio.h>
#include "time.h"

#include "Math/Color4f.h"
#include "Math/Vector3f.h"
#include "ParticleSystem/Particle.h"
#include "ParticleSystem/ParticleSystem.h"
#include "ParticleSystem/Strategy.h"
#include "ParticleSystem/EmitManager.h"
#include "WindManager.h"

extern bool LoadBMP();

int		AREA_WIDTH = 640;
int		AREA_HEIGHT = 640;
int 		frameTime;
int		timeStart;
int		frameStart;
int		curFps;
char		*lastAction;
int		numOfParticlesForEmit;
bool		moveWindXY;
int testFpsFromCount[1000][2];
int curTest;
double flameX = 4.5;
double flameY = 1;
struct Point2D {
	GLfloat x;
	GLfloat y;
};

Vector3f windVector = Vector3f(-0.1, 0, 0);

Point2D		cursor = {AREA_WIDTH / 2, AREA_HEIGHT / 2}; 	//позиция курсора
char s[80];
double emitDelta;
int emitSize;

FireSystem	fire;
SmokeSystem	smoke;

EmitManager	fireEmit;
EmitManager	smokeEmit;

void updateEmit() {
	smokeEmit.Clear();
	smokeEmit.AddPow(Vector3f(6,1,0), Vector3f(7,1,0), emitDelta, emitSize);
	fireEmit.Clear();
	fireEmit.AddPow(Vector3f(3,1,0), Vector3f(4,1,0), emitDelta, emitSize);
}

void snapshot(char* filename) {
	int windowWidth = AREA_WIDTH;
	int windowHeight = AREA_HEIGHT; 
	byte* bmpBuffer = (byte*)malloc(windowWidth*windowHeight*3);
	if (!bmpBuffer) return;

	glReadPixels((GLint)1, (GLint)0,(GLint)windowWidth-1, (GLint)windowHeight-1,GL_RGB, GL_UNSIGNED_BYTE, bmpBuffer);

	for (int i = 0; i < windowWidth*windowHeight*3; i+=3) {
		int a = bmpBuffer[i+2];
		bmpBuffer[i+2] = bmpBuffer[i];
		bmpBuffer[i] = a;
	}

	FILE *filePtr = fopen(filename, "wb");
	if (!filePtr)return;

	BITMAPFILEHEADER bitmapFileHeader;
	BITMAPINFOHEADER bitmapInfoHeader;

	bitmapFileHeader.bfType = 0x4D42; //"BM"
	bitmapFileHeader.bfSize = windowWidth*windowHeight*3;
	bitmapFileHeader.bfReserved1 = 0;
	bitmapFileHeader.bfReserved2 = 0;
	bitmapFileHeader.bfOffBits =
	sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	bitmapInfoHeader.biSize = sizeof(BITMAPINFOHEADER);
	bitmapInfoHeader.biWidth = windowWidth-1;
	bitmapInfoHeader.biHeight = windowHeight-1;
	bitmapInfoHeader.biPlanes = 1;
	bitmapInfoHeader.biBitCount = 24;
	bitmapInfoHeader.biCompression = BI_RGB;
	bitmapInfoHeader.biSizeImage = 0;
	bitmapInfoHeader.biXPelsPerMeter = 0; // ?
	bitmapInfoHeader.biYPelsPerMeter = 0; // ?
	bitmapInfoHeader.biClrUsed = 0;
	bitmapInfoHeader.biClrImportant = 0;

	fwrite(&bitmapFileHeader, sizeof(BITMAPFILEHEADER), 1, filePtr);
	fwrite(&bitmapInfoHeader, sizeof(BITMAPINFOHEADER), 1, filePtr);
	fwrite(bmpBuffer, windowWidth*windowHeight*3, 1, filePtr);
	fclose(filePtr);

	free(bmpBuffer);
}

void makeSnapshot() {
	lastAction = "screenshot maked";
	char dateStr [9], timeStr [9], filename[80] = "screenshot_";

	_strdate(dateStr);
	_strtime(timeStr);
	char *ptr = dateStr;
	while (*ptr) { if (*ptr == '/') *ptr = '.'; ptr++; }

	*ptr = '_'; *(ptr+1) = 0;

	ptr = timeStr;
	while (*ptr) { if (*ptr == ':') *ptr = '.'; ptr++; }

	strcat(filename,dateStr);
	strcat(filename,timeStr);
	strcat(filename,".bmp");
	snapshot(filename);
}

void drawText(char *text, double x, double y) {
	glRasterPos2f(x, y);
	for (char* c = text; *c; c++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
}

void printPreferenceToScreen(char *pref, char* num, double x, double y) {
	char s[80];
	strcpy(s, pref);
	strcat(s, ": ");
	strcat(s, num);
	drawText(s, x , y);
}

void printPreferenceToScreen(char *pref, int num, double x, double y) {
	char s[80];
	sprintf(s,"%s: %d", pref, num);
	drawText(s, x , y);
}

unsigned long long PCFreq = 0.0;
unsigned long long CounterStart = 0;

void StartCounter() {
	QueryPerformanceFrequency((LARGE_INTEGER*)&PCFreq);
	QueryPerformanceCounter((LARGE_INTEGER*)&CounterStart);
}

double GetCounter() {
    unsigned long long curCounter;
    QueryPerformanceCounter((LARGE_INTEGER*)&curCounter);
    return double(curCounter-CounterStart)/PCFreq;
}

void startMeasureFPS() {
	StartCounter();
	frameStart = frameTime;
}

void calculateFPS() {
	//printf("counter: %g\n", GetCounter());
	curFps = (frameTime - frameStart)/GetCounter();
}

void init() {
	frameTime = 0;
	curFps = 0;
	lastAction = "";
	emitDelta = 0.03;
	emitSize = 7;
	curTest = 0;
	startMeasureFPS();
	numOfParticlesForEmit = 4;
	glClearColor(0, 0, 0, 1);
	fire.Init();
	fire.AddWind(windVector,100000);
	fireEmit.Add(Vector3f(4.5,1,0));
	smoke.Init();
	//updateEmit();
	smokeEmit.AddPow(Vector3f(7,1,0), Vector3f(9,1,0), 0.03, 2);
}

inline void DrawParticle(float size_x, float size_y)
{
    glBegin(GL_TRIANGLE_FAN);
        glTexCoord2f(0.0,0.0); 
	glVertex3f(0.0,0.0,0.0);
       glTexCoord2f(1.0,0.0);
	glVertex3f(size_x,0.0,0.0);
        glTexCoord2f(1.0,1.0); 
	glVertex3f(size_x,size_y,0.0);
       glTexCoord2f(0.0,1.0); 
	glVertex3f(0.0,size_y,0.0);
    glEnd();
}

void glColor3fWithAlpha(double r, double g, double b, double a) {
	glColor3f(r*(1-a), g*(1-a), b*(1-a));
}

void mouseMotion (int x, int y) {
	y = AREA_HEIGHT - y;
	double wx = x * 10.0 / AREA_HEIGHT;
	double wy = y * 10.0 / AREA_WIDTH - 0.5;
	if (wx == flameX) fire.windManager.winds[0].first.X = 0;
	if (wx < flameX) fire.windManager.winds[0].first.X = 0.1;
	if (wx > flameX) fire.windManager.winds[0].first.X = -0.1;
	fire.windManager.winds[0].first.Y = wy;// * 0.01;
	fire.windManager.winds[0].first.Z = wx;// * 0.01;
	//fire.windManager.winds[0].second = 100;
	sprintf(s, "wind replaced to (%g, %g)", wx, wy);
	lastAction = s;
	//printf("(%g, %g, %g)\n", windVector.X, windVector.Y, windVector.Z);
	glutPostRedisplay();
}


void display(void) {
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();

	glEnable(GL_BLEND); // Вкл. Blending

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);    // Сделаем значение прозрачности 1:1

	glEnable(GL_TEXTURE_2D);
		for (int i = 0; i < fire.Count(); ++i) {			
			glColor3fWithAlpha(fire[i].Color.Red, fire[i].Color.Green, fire[i].Color.Blue, fire[i].Color.Alpha);
			
			glPushMatrix ();
				glTranslatef(fire[i].Position.X, fire[i].Position.Y, fire[i].Position.Z);
				DrawParticle(fire[i].Size.X, fire[i].Size.Y);
				//glBegin(GL_POINTS); glVertex3f(0,0,0); glEnd();
			glPopMatrix ();
		}
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);

	glColor3f(1, 0.4, 0);
	printPreferenceToScreen("fps", curFps, 1, 9);
	printPreferenceToScreen("fire count", fire.Count(), 1, 8.8);
	
	printPreferenceToScreen("state", lastAction, 1, 0.5);
	
	glFlush();
	glutSwapBuffers();
	
}

void reshape(int width,int height) {
	glViewport(0, 0, AREA_WIDTH = width, AREA_HEIGHT = height);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, 10, 0, 10);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void fps(int value) {
	calculateFPS();
	startMeasureFPS();
	glutTimerFunc(500, fps, 1);
}


void keyboard (unsigned char key, int x, int y) {	
	switch (key) {
		case 'p':case 'P':case 'з':case 'З':
			makeSnapshot();
		case 'w':
			flameY+=0.1;
			sprintf(s, "flame replased to (%g, %g)", flameX, flameY);
			lastAction = s;
			break;
		case 's':
			flameY-=0.1;
			sprintf(s, "flame replased to (%g, %g)", flameX, flameY);
			lastAction = s;
			break;
		case 'a':
			flameX-=0.1;
			sprintf(s, "flame replased to (%g, %g)", flameX, flameY);
			lastAction = s;
			break;
		case 'd':
			flameX+=0.1;
			sprintf(s, "flame replased to (%g, %g)", flameX, flameY);
			lastAction = s;
			break;
		break;
		case 27 : 	//esc - выход
			exit(0);		
	}
	glutPostRedisplay();
}



void timer(int value) {
	frameTime++;

	

	fire.Update(frameTime*1.0/2);
	fireEmit.Clear();
	fireEmit.Add(Vector3f(flameX, flameY,0));
	fire.Emit(fireEmit, 9);


	glutPostRedisplay();
	glutTimerFunc(20,timer,0);
}

int main(int argc, char **argv) {
	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(50, 25);
	glutInitWindowSize(AREA_WIDTH, AREA_HEIGHT);
	glutCreateWindow("Particle System Demonstration");

	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutMotionFunc(mouseMotion);
	glutPassiveMotionFunc(mouseMotion);
	
	init();
	LoadBMP();
	reshape(AREA_WIDTH, AREA_HEIGHT);
	
	glutTimerFunc(10, timer, 0);
	glutTimerFunc(10, fps, 1);
	
	
	glutMainLoop();
	
	return 0;
}