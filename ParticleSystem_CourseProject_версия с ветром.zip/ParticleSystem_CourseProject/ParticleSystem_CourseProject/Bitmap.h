/*==============================================================================
Header Files and Global Defines
==============================================================================*/
#include "resource.h"       //Header File for Resource IDs and Headers

/*==============================================================================
Global Variables
==============================================================================*/
//~~~~~Bitmap Variables
    unsigned int texture[MAX_TEXTURE];
    struct Image {
        unsigned long sizeX;
        unsigned long sizeY;
        char *data;
    };
    typedef struct Image Image;

/*==============================================================================
FUNCTION PROTOTYPES
==============================================================================*/
//Initialize Bitmaps
bool LoadBMP();

//Bitmap Loader taken from nehe.gamedev.net and http://www.dcs.ed.ac.uk/~mxr/gfx/2d/BMP.txt
bool ImageLoad(char *filename, Image *image);

/*==============================================================================
FUNCTION DEFINITIONS
==============================================================================*/
bool LoadBMP()
{
    int loop;
    Image *image[MAX_TEXTURE];

    for(loop=0; loop < MAX_TEXTURE; loop++)
    {
        image[loop] = (Image *) malloc(sizeof(Image));
        if(image[loop] == NULL)
        {
            MessageBox(GetActiveWindow(),"Error allocating space for image", "Test", MB_OK);
	        return FALSE;
    	}
    }
    if(!ImageLoad("Data/Particle.bmp", image[IDB_PARTICLE_0]))
    {
        return FALSE;
    }
    glGenTextures(MAX_TEXTURE, &texture[0]);
    for(loop=0; loop < MAX_TEXTURE; loop++)
    {
        glBindTexture(GL_TEXTURE_2D, texture[loop]);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D, 0, 3, image[loop]->sizeX, image[loop]->sizeY, 
                    0, GL_RGB, GL_UNSIGNED_BYTE, image[loop]->data);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S ,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T ,GL_LINEAR);
        glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    }
    for (loop=0; loop<MAX_TEXTURE; loop++)
    {
	    if (image[loop])
	    {
		   if (image[loop]->data)
		   {
			   free(image[loop]->data);
	       }
		   free(image[loop]);    	  		      		  		      		 
	    }
	}
    return TRUE;
}

bool ImageLoad(char *filename, Image *image)
{
    HWND hwnd=GetActiveWindow();
    FILE *file;
    unsigned long size;
    unsigned long i;
    unsigned short int planes;
    unsigned short int bpp;
    char temp;
    char error_elucidate[128]={0};
    const char title[]="Error";
//Check if file is there
    if((file = fopen(filename, "rb"))==NULL)
    {
        strcpy(error_elucidate, "File not found:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
		return FALSE;
    }
    fseek(file, 18, SEEK_CUR);
//Read size of file
    if((i = fread(&image->sizeX, 4, 1, file)) != 1)
    {
        strcpy(error_elucidate, "Can not read width:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
		return FALSE;
    }
    if((i = fread(&image->sizeY, 4, 1, file)) != 1)
    {
        strcpy(error_elucidate, "Can not read height:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
	    return FALSE;
    }
    size = image->sizeX * image->sizeY * 3;
//Read plane information
    if((fread(&planes, 2, 1, file)) != 1) 
    {
        strcpy(error_elucidate, "Can not read planes:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
	 	return FALSE;
    }
    if(planes != 1) 
    {
        strcpy(error_elucidate, "Bitmap file has to have 1 plane:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
		return FALSE;
    }
//Read bpp information
    if((i = fread(&bpp, 2, 1, file)) != 1)
    {
        strcpy(error_elucidate, "Can not read bpp:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
		return FALSE;
    }
    if(bpp != 24)
    {
        strcpy(error_elucidate, "Bitmap is not 24-bit:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
		return FALSE;
    }
    fseek(file, 24, SEEK_CUR);
//Read the data contained in the stipulated bitmap
    image->data = (char *) malloc(size);
    if(image->data == NULL)
    {
        strcpy(error_elucidate, "Memory could not be allocated for image:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
	 	return FALSE;	
    }
    if((i = fread(image->data, size, 1, file)) != 1)
    {
        strcpy(error_elucidate, "Bitmap could not be read:");
        strcat(error_elucidate, filename);
	    MessageBox(hwnd, error_elucidate, title, MB_OK |MB_ICONERROR);
		return FALSE;
    }
//Reverse all of the colors. (bgr -> rgb)
    for (i=0;i<size;i+=3) 
    {
	    temp = image->data[i];
		image->data[i] = image->data[i+2];
	    image->data[i+2] = temp;
    }
    return TRUE;
}

