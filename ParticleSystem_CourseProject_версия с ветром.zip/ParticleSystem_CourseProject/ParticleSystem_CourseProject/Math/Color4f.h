#ifndef _Color4f_
#define _Color4f_

/* Color4f - хранение и обработка цвета в формате RGBA
 * Пример работы:
 *	Color4f color = Color4f(r,g,b,a)
 *	Color4f color1 = Color4f()
 * 	color.Red = 0.1
 * 	int t = color == color1
 */

struct Color4f {
	double	Red;
	double	Green;
	double	Blue;
	double	Alpha;

	Color4f(double red, double green, double blue, double alpha) {
		Red = red; Green = green; Blue = blue; Alpha = alpha;
	}

	Color4f() {
		Red = 0; Green = 0; Blue = 0; Alpha = 0;
	}


	Color4f& operator = (const Color4f &other) {
		Red = other.Red;
		Green = other.Green;
		Blue = other.Blue;
		Alpha = other.Alpha;
		return *this;
	}

	bool operator == (const Color4f &right) {
		return ((Red == right.Red) &&
			(Green == right.Green) &&
			(Blue == right.Blue) &&
			(Alpha == right.Alpha));
	}

	bool operator != (const Color4f &right) {
		return ((Red != right.Red) ||
			(Green != right.Green) ||
			(Alpha != right.Alpha) ||
			(Blue != right.Blue));
	}
};

#endif