#include <windows.h>
#include <GL/gl.h>
#include "GL/glut.h"
#include <string.h>
#include <stdio.h>
#include "time.h"

#include "Math/Color4f.h"
#include "Math/Vector3f.h"
#include "ParticleSystem/Particle.h"
#include "ParticleSystem/ParticleSystem.h"
#include "ParticleSystem/Strategy.h"
#include "ParticleSystem/EmitManager.h"

extern bool LoadBMP();

int		AREA_WIDTH = 640;
int		AREA_HEIGHT = 640;
int 		frameTime;
int		timeStart;
int		frameStart;
int		curFps;
char		*lastAction;
int		numOfParticlesForEmit;

int testFpsFromCount[1000][2];
int curTest;

char s[80];
double emitDelta;
int emitSize;

FireSystem	fire;
SmokeSystem	smoke;

EmitManager	fireEmit;
EmitManager	smokeEmit;

void updateEmit() {
	smokeEmit.Clear();
	smokeEmit.AddPow(Vector3f(6,1,0), Vector3f(7,1,0), emitDelta, emitSize);
	fireEmit.Clear();
	fireEmit.AddPow(Vector3f(3,1,0), Vector3f(4,1,0), emitDelta, emitSize);
}

void snapshot(char* filename) {
	int windowWidth = AREA_WIDTH;
	int windowHeight = AREA_HEIGHT; 
	byte* bmpBuffer = (byte*)malloc(windowWidth*windowHeight*3);
	if (!bmpBuffer) return;

	glReadPixels((GLint)1, (GLint)0,(GLint)windowWidth-1, (GLint)windowHeight-1,GL_RGB, GL_UNSIGNED_BYTE, bmpBuffer);

	for (int i = 0; i < windowWidth*windowHeight*3; i+=3) {
		int a = bmpBuffer[i+2];
		bmpBuffer[i+2] = bmpBuffer[i];
		bmpBuffer[i] = a;
	}

	FILE *filePtr = fopen(filename, "wb");
	if (!filePtr)return;

	BITMAPFILEHEADER bitmapFileHeader;
	BITMAPINFOHEADER bitmapInfoHeader;

	bitmapFileHeader.bfType = 0x4D42; //"BM"
	bitmapFileHeader.bfSize = windowWidth*windowHeight*3;
	bitmapFileHeader.bfReserved1 = 0;
	bitmapFileHeader.bfReserved2 = 0;
	bitmapFileHeader.bfOffBits =
	sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	bitmapInfoHeader.biSize = sizeof(BITMAPINFOHEADER);
	bitmapInfoHeader.biWidth = windowWidth-1;
	bitmapInfoHeader.biHeight = windowHeight-1;
	bitmapInfoHeader.biPlanes = 1;
	bitmapInfoHeader.biBitCount = 24;
	bitmapInfoHeader.biCompression = BI_RGB;
	bitmapInfoHeader.biSizeImage = 0;
	bitmapInfoHeader.biXPelsPerMeter = 0; // ?
	bitmapInfoHeader.biYPelsPerMeter = 0; // ?
	bitmapInfoHeader.biClrUsed = 0;
	bitmapInfoHeader.biClrImportant = 0;

	fwrite(&bitmapFileHeader, sizeof(BITMAPFILEHEADER), 1, filePtr);
	fwrite(&bitmapInfoHeader, sizeof(BITMAPINFOHEADER), 1, filePtr);
	fwrite(bmpBuffer, windowWidth*windowHeight*3, 1, filePtr);
	fclose(filePtr);

	free(bmpBuffer);
}

void makeSnapshot() {
	lastAction = "screenshot maked";
	char dateStr [9], timeStr [9], filename[80] = "screenshot_";

	_strdate(dateStr);
	_strtime(timeStr);
	char *ptr = dateStr;
	while (*ptr) { if (*ptr == '/') *ptr = '.'; ptr++; }

	*ptr = '_'; *(ptr+1) = 0;

	ptr = timeStr;
	while (*ptr) { if (*ptr == ':') *ptr = '.'; ptr++; }

	strcat(filename,dateStr);
	strcat(filename,timeStr);
	strcat(filename,".bmp");
	snapshot(filename);
}

void drawText(char *text, double x, double y) {
	glRasterPos2f(x, y);
	for (char* c = text; *c; c++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
}

void printPreferenceToScreen(char *pref, char* num, double x, double y) {
	char s[80];
	strcpy(s, pref);
	strcat(s, ": ");
	strcat(s, num);
	drawText(s, x , y);
}

void printPreferenceToScreen(char *pref, int num, double x, double y) {
	char s[80];
	sprintf(s,"%s: %d", pref, num);
	drawText(s, x , y);
}

unsigned long long PCFreq = 0.0;
unsigned long long CounterStart = 0;

void StartCounter() {
	QueryPerformanceFrequency((LARGE_INTEGER*)&PCFreq);
	QueryPerformanceCounter((LARGE_INTEGER*)&CounterStart);
}

double GetCounter() {
    unsigned long long curCounter;
    QueryPerformanceCounter((LARGE_INTEGER*)&curCounter);
    return double(curCounter-CounterStart)/PCFreq;
}

void startMeasureFPS() {
	StartCounter();
	frameStart = frameTime;
}

void calculateFPS() {
	//printf("counter: %g\n", GetCounter());
	curFps = (frameTime - frameStart)/GetCounter();
}

void init() {
	frameTime = 0;
	curFps = 0;
	lastAction = "";
	emitDelta = 0.03;
	emitSize = 7;
	curTest = 0;
	startMeasureFPS();
	numOfParticlesForEmit = 4;
	glClearColor(0, 0, 0, 1);
	fire.Init();
	fireEmit.AddPow(Vector3f(2,1,0), Vector3f(4,1,0), 0.03, 7);
	smoke.Init();
	//updateEmit();
	smokeEmit.AddPow(Vector3f(7,1,0), Vector3f(9,1,0), 0.03, 2);
}

inline void DrawParticle(float size_x, float size_y)
{
    glBegin(GL_TRIANGLE_FAN);
        glTexCoord2f(0.0,0.0); 
	glVertex3f(0.0,0.0,0.0);
       glTexCoord2f(1.0,0.0);
	glVertex3f(size_x,0.0,0.0);
        glTexCoord2f(1.0,1.0); 
	glVertex3f(size_x,size_y,0.0);
       glTexCoord2f(0.0,1.0); 
	glVertex3f(0.0,size_y,0.0);
    glEnd();
}

void glColor3fWithAlpha(double r, double g, double b, double a) {
	glColor3f(r*(1-a), g*(1-a), b*(1-a));
}

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();

	glEnable(GL_BLEND); // Вкл. Blending

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);    // Сделаем значение прозрачности 1:1

	glEnable(GL_TEXTURE_2D);
	
		for (int i = 0; i < smoke.Count(); ++i) {			
			glColor4f(smoke[i].Color.Red, smoke[i].Color.Green, smoke[i].Color.Blue, smoke[i].Color.Alpha);
			
			glPushMatrix ();
				glTranslatef(smoke[i].Position.X, smoke[i].Position.Y, smoke[i].Position.Z);
				DrawParticle(smoke[i].Size.X, smoke[i].Size.Y);
				//glBegin(GL_POINTS); glVertex3f(0,0,0); glEnd();
			glPopMatrix ();
		}
		
	
		for (int i = 0; i < fire.Count(); ++i) {			
			glColor3fWithAlpha(fire[i].Color.Red, fire[i].Color.Green, fire[i].Color.Blue, fire[i].Color.Alpha);
			
			glPushMatrix ();
				glTranslatef(fire[i].Position.X, fire[i].Position.Y, fire[i].Position.Z);
				DrawParticle(fire[i].Size.X, fire[i].Size.Y);
				//glBegin(GL_POINTS); glVertex3f(0,0,0); glEnd();
			glPopMatrix ();
		}

		
	
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);

	//рисуем прямоугольник закрывающий эмитеры
	/*glColor3f(0,0,0);
	glBegin(GL_QUADS);
	glVertex3f(3.5,1,0);
		glVertex3f(3.5,1.3,0);
		glVertex3f(6.5,1.3,0);
		glVertex3f(6.5,1,0);
	glEnd();
	*/
	glColor3f(1, 0.4, 0);
	printPreferenceToScreen("fps", curFps, 1, 9);
	printPreferenceToScreen("fire count", fire.Count(), 1, 8.8);
	
	printPreferenceToScreen("state", lastAction, 1, 0.5);
	
	glFlush();
	glutSwapBuffers();
	
}

void reshape(int width,int height) {
	glViewport(0, 0, AREA_WIDTH = width, AREA_HEIGHT = height);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, 10, 0, 10);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void fps(int value) {
	calculateFPS();
	startMeasureFPS();
	glutTimerFunc(500, fps, 1);
}


void keyboard (unsigned char key, int x, int y) {	
	switch (key) {
		case 'p':case 'P':case 'з':case 'З':
			makeSnapshot();
		break;
		/*case ')':case '0':
			emitSize++;
			updateEmit();		
			sprintf(s,"emit size = %d", emitSize);
			lastAction = s;
		break;
		case '(':case '9':
			emitSize--;
			if (emitSize < 0) emitSize = 0;
			updateEmit();
			sprintf(s,"emit size = %d", emitSize);
			lastAction = s;
		break;
		case ']':case '}':case 'ъ':case 'Ъ':
			emitDelta += 0.01;
			updateEmit();		
			sprintf(s,"emit delta = %g", emitDelta);
			lastAction = s;
		break;
		case '[':case '{':case 'х':case 'Х':
			emitDelta -= 0.01;
			if (emitDelta < 0) emitDelta = 0;
			updateEmit();
			sprintf(s,"emit delta = %g", emitDelta);
			lastAction = s;
		break;
		case '+':case '=':
			numOfParticlesForEmit++;
			sprintf(s,"num of particles for emit = %d",numOfParticlesForEmit);
			lastAction = s;
		break;
		case '-':case '_':
			numOfParticlesForEmit--;
			if (numOfParticlesForEmit < 0) numOfParticlesForEmit = 0;
			sprintf(s,"num of particles for emit = %d",numOfParticlesForEmit);
			lastAction = s;*/
		break;
		case 27 : 	//esc - выход
			exit(0);		
	}
	glutPostRedisplay();
}

void timer(int value) {
	frameTime++;
	fire.Update(frameTime*1.0/2);
	/*if (curTest < 100) {
		testFpsFromCount[curTest][0] = curFps;
		testFpsFromCount[curTest++][1] = fire.Count();
	} else {
		FILE *f = fopen("test_with_draw_as_dot.log","w");
		for (int i = 0; i < 100; ++i)
			fprintf(f, "%d %d\n", testFpsFromCount[i][0], testFpsFromCount[i][1]);
		fclose(f);
		exit(0);
	}*/
	smoke.Update(frameTime);
	fire.Emit(fireEmit, 5);
	smoke.Emit(smokeEmit, 1);

	glutPostRedisplay();
	glutTimerFunc(20,timer,0);
}

int main(int argc, char **argv) {
	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(50, 25);
	glutInitWindowSize(AREA_WIDTH, AREA_HEIGHT);
	glutCreateWindow("Particle System Demonstration");

	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	
	init();
	LoadBMP();
	reshape(AREA_WIDTH, AREA_HEIGHT);
	
	glutTimerFunc(10, timer, 0);
	glutTimerFunc(10, fps, 1);
	
	
	glutMainLoop();
	
	return 0;
}