/*==============================================================================
Header Fils/Defines
==============================================================================*/
//~Header Files
#include <windows.h>        //Header File for Standard Windows Functions
#include <math.h>           //Header File for Math Functions
#include <time.h>           //Header File for Time Functions
#include <gl\gl.h>          //Header File for OpenGL
#include <gl\glu.h>         //Header File for Glu32
#include <stdio.h>          //Header File for I/O

//~Defines
#define MAX_TEXTURE                                     1
#define IDB_PARTICLE_0                                  0
#define IDC_STATIC                                     -1

/*==============================================================================
Resource IDs
==============================================================================*/
//=====Menu
//~Main
#define IDR_MENU                                      101
#define IDM_OPTIONS                                 40001
#define IDM_ABOUT                                   40002
#define IDM_EXIT                                    40003

//=====Dialog Box
//~Options
#define IDD_OPTIONS                                   102
#define IDC_OPTIONS_OK                               1001
#define IDC_OPTIONS_CANCEL                           1002
#define IDC_OPTIONS_COUNT                            1003
#define IDC_OPTIONS_SPEED                            1004
#define IDC_OPTIONS_TOPX                             1005
#define IDC_OPTIONS_TOPY                             1006
#define IDC_OPTIONS_BOTTOMX                          1007
#define IDC_OPTIONS_BOTTOMY                          1008
#define IDC_OPTIONS_FADE                             1009
#define IDC_OPTIONS_POINT                            1010
#define IDC_OPTIONS_RED                              1011
#define IDC_OPTIONS_GREEN                            1012
#define IDC_OPTIONS_BLUE                             1013

//=====Icons
//~Main
