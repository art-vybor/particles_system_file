#ifndef _Particle_
#define _Particle_

#include "../Math/Color4f.h"
#include "../Math/Vector3f.h"

/* Particle - класс, задающий частицу
 * 	Color,Position, Size - необходимы для отрисовки
 * 	Gravity - внешняя действующая сила
 *	Velocity - скорость
 * 	Life - оставшееся время жизни
 */

struct Particle {
	double	 Life;
	Vector3f Velocity;
	Vector3f Gravity;

	Color4f	 Color;
	Vector3f Position;
	Vector3f Size;
};

#endif