#ifndef _ParticleSystem_
#define _ParticleSystem_

#include <stdlib.h>
#include "../Math/Vector3f.h"
#include "Particle.h"
#include <omp.h>
#include "Strategy.h"
#include "EmitManager.h"
#include "WindManager.h"

/* ParticleSystem - шаблон системы частиц
   frameTime в секундах
*/

template<int MaxParticleCount, class InitPolicy, class UpdatePolicy>
class ParticleSystem {
private:
	InitPolicy	particleInit; 			//инициализация частицы
	UpdatePolicy	particleUpdate; 		//обновление состояния частицы
	Particle	particles[MaxParticleCount]; 	//массив частиц
	int		particleCount; 			//количество живых частиц
	bool		isAlive; 			//существование системы частиц
	double		lastFrameTime;			//последний отрисованный кадр
public:
	WindManager	windManager;
public:
	inline void Emit(EmitManager emitPoints, int num) {
		while (num--) {
			for (int i = 0; i < emitPoints.Size(); ++i) {
				if (particleCount == MaxParticleCount) {
					printf("Reached the limit of the number of particles. Particle will not be added.\n");
				} else {
					particles[particleCount].Position = emitPoints[i];
					particleInit(&particles[particleCount++], 0);
				}
			}
		}
	}

	
	inline void Update(double frameTime) {
		double dFrameTime = lastFrameTime == 0 ? 0 : abs(frameTime - lastFrameTime);
		if (isAlive) {
			if (particleCount) {
				for (int i = 0; i < particleCount; i++) {
					if (particles[i].Life <= 0)
						particles[i] = particles[--particleCount];
				}
				if (particleCount == 0) isAlive = false;
			}
			for (int i = 0; i < particleCount; i++) {
				particleUpdate(&particles[i], dFrameTime);
			}

			for (int i = 0; i < particleCount; i++) {
				windManager.calculate(&particles[i]);
			}
			windManager.update();
		}
		else particleCount = 0;

		lastFrameTime = frameTime;
	}
	
	Particle &operator [](int i) {
		if (i < particleCount)
			return particles[i];
		throw new exception();
        }

	void ClearWind() {
		windManager.Clear();
        }

	void AddWind(Vector3f wind, int d) {
		windManager.Add(wind, d);
	}

	int Count() {
		return particleCount;
	}

	void Init() {
		isAlive = true;
		particleCount = 0;
		lastFrameTime = 0;
	}
};

/* Fire - система частиц для реализации огня */

typedef ParticleSystem
	<100000, CompletePolicy<Fire_InitLife, NullPolicy, InitSize, Fire_InitVelocity, Fire_InitColor, NullPolicy>,
	CompletePolicy<Fire_ProcLife, Fire_ProcPosition, NullPolicy, Fire_ProcSize, Fire_ProcColor, NullPolicy> >
FireSystem;

typedef ParticleSystem
	<30000, CompletePolicy<Smoke_InitLife, NullPolicy, InitSize, Smoke_InitVelocity, Smoke_InitColor, NullPolicy>,
	CompletePolicy<Smoke_ProcLife, Smoke_ProcPosition, NullPolicy, Smoke_ProcSize, Smoke_ProcColor, NullPolicy> >
SmokeSystem;


#endif
