#ifndef _WindManager_
#define _WindManager_

#include <vector>
#include "Math/Vector3f.h"

/* class EmitAres - provides a convenient way to control the emitter. */

typedef pair<Vector3f, int> Wind;

class WindManager {
public:
	vector<Wind> winds;
	
public:
	WindManager() {
	}

	void Clear() {
		winds.clear();
	}

	void Add(Wind wind) {
		winds.push_back(wind);
	}

	void Add(Vector3f windVector, int count) {
		Add(make_pair(windVector, count));
	}

	/*int Size() {
		return winds.size();
	}

	Wind &operator [](int i) {
		if (i < Size())
			return winds[i];
		throw new exception();
        }*/
	void calculate(Particle *particle) {
		for (vector<Wind>::iterator it = winds.begin(); it != winds.end(); ++it) {
			
			
			ProcWind(particle, (*it).first);
		}
	}

	void update() {
		//printf("winds:\n");
		for (vector<Wind>::iterator it = winds.begin(); it != winds.end(); ++it) {
		//	printf("\t (%g, %g, %g) - %d\n", (*it).first.X, (*it).first.Y, (*it).first.Z, (*it).second);
			(*it).second--; }
		/*for (vector<Wind>::iterator it = winds.begin(); it != winds.end(); ++it) {
			if ((*it).second == 0) winds.erase(it);
		}*/
		vector<Wind>::iterator iter = winds.begin();
		
		while (iter != winds.end()) {
			if ((*iter).second == 0) {
				iter = winds.erase(iter);
			}
			else {
				++iter;
			}
		}

		//numbers.erase(remove_if(winds.begin(), winds.end(), bind2nd(greater<int>(), 4)), winds.end() );
	}

	void ProcWind(Particle *particle, Vector3f wind) {
		//printf("(%g, %g, %g)\n", wind.X, wind.Y, wind.Z);
		if (particle->Position.Y > wind.Y - 0.1 && particle->Position.Y < wind.Y + 0.1) {
			//double dy = abs(particle->Position.Y - windVector.Y);
			//double y = -pow(dy, 2.0) + 1;
			double x =  abs(wind.Z - particle -> Position.X);
			if (x <= 1) x = 1;
			else x = pow(x, 1.0);
			printf("\t%g\n", particle -> Position.X);
			particle -> Position.X = particle -> Position.X + wind.X*(1/x);
			printf("\t%g\n", particle -> Position.X);
		}
	}
};

#endif