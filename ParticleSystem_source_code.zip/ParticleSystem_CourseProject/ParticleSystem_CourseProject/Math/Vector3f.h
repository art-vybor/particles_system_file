#ifndef _Vector3f_
#define _Vector3f_

#include <string>
#include <stdio.h>
using namespace std;


/* Vector3f - класс для работы с 3х-мерными векторами
 * Пример использования:
 * 	Vector3f vector = Vector3f(X, Y, Z);
 *	Vector3f vector1 = Vector3f(X, Y, Z);
 *	vector *= vector1 + vector;
 *	vector.X = 3;
 *	cout << vector.ToString();
 */

struct Vector3f {
	GLfloat X;
	GLfloat Y;
	GLfloat Z;
	
	Vector3f() {
		X = 0; Y = 0; Z = 0;
	}

	Vector3f(double _X, double _Y, double _Z) {
		X = _X; Y = _Y; Z = _Z;
        }

	Vector3f(const Vector3f &other) {
		X = other.X;
		Y = other.Y;
		Z = other.Z;
        }

	Vector3f Normalize() {
		double d = sqrt(X*X + Y*Y + Z*Z);
		return Vector3f(X/d, Y/d, Z/d);
	}

	Vector3f operator + (Vector3f other) {
		return Vector3f(X + other.X, Y + other.Y, Z + other.Z);
	}

	Vector3f& operator += (const Vector3f& other) {
		X += other.X;
		Y += other.Y;
		Z += other.Z;
		return *this;
	}

	Vector3f operator * (Vector3f other) {
		return Vector3f(X * other.X, Y * other.Y, Z * other.Z);
	}

	Vector3f operator * (double value) {
		return Vector3f(X * value, Y * value, Z * value);
	}

	Vector3f& operator *= (const Vector3f& other) {
		X *= other.X;
		Y *= other.Y;
		Z *= other.Z;
		return *this;
	}

	Vector3f& operator *= (const double d) {
		X *= d;
		Y *= d;
		Z *= d;
		return *this;
	}

	Vector3f operator - (Vector3f other) {
		return Vector3f(X - other.X, Y - other.Y, Z - other.Z);
	}

	Vector3f& operator -= (const Vector3f& other) {
		X -= other.X;
		Y -= other.Y;
		Z -= other.Z;
		return *this;
	}

	Vector3f operator / (Vector3f other) {
		return Vector3f(X / other.X, Y / other.Y, Z / other.Z);
	}

	Vector3f operator / (double value) {
		return Vector3f(X / value, Y / value, Z / value);
	}

	Vector3f& operator /= (const Vector3f& other) {
		X /= other.X;
		Y /= other.Y;
		Z /= other.Z;
		return *this;
	}

	bool operator == (Vector3f Other) {
		return ((X == Other.X) && (Y == Other.Y) && (Z == Other.Z));
	}
	
	Vector3f operator= (Vector3f other) {
		X = other.X;
		Y = other.Y;
		Z = other.Z;
		return *this;
	}

	string ToString() {
		char s[80];
		sprintf(s, "(%g, %g, %g)", X, Y, Z);
		return s;
	}	
};

#endif