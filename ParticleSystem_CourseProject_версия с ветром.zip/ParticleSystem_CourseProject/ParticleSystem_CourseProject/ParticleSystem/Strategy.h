#ifndef _Strategy_
#define _Strategy_

#include "stdlib.h"
#include "../Math/Color4f.h"
#include "../Math/Vector3f.h"
#include "Particle.h"
#include <cmath>

/* Этот файл содержит стратегии и класс, отвечающий за их аггрегацию */

/* CompletePolicy - группировщик
 * 	объединяет шесть стратегий в одну
 */

template<class Life, class Position, class Size, class Velocity, class Color, class Gravity>
class CompletePolicy {
public:
	Life		life;
	Position	position;
	Size		size;
	Velocity	velocity;
	Color		color;
	Gravity		gravity;

	inline void operator () (Particle *particle, double frameTime) {
		life		(particle, frameTime);
		velocity	(particle, frameTime);
		position	(particle, frameTime);
		size		(particle, frameTime);
		color		(particle, frameTime);
		gravity		(particle, frameTime);
	}
};

/* Стратегии инициализации цвета */
struct Fire_InitColor {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Color = Color4f(1, 0.5, 0.1, 0.6);
	}
};

struct Smoke_InitColor {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Color = Color4f(0.02, 0.02, 0.02, 0);
	}
};
/* Стратегии инициализации размера */
struct InitSize {
	inline void operator () (Particle *particle, double frameTime) {
		double t = 0.7;// + (rand() % 10)*1.0/25;
		particle -> Size = Vector3f(t, t+0.05, 0.0f);
	}
};

/* Стратегии инициализации времени жизни */
struct Fire_InitLife {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Life = 300 + rand()%100;
	}
};

struct Smoke_InitLife {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Life = 300 + rand()%50; //частица живёт от 80 до 100 .
	}
};

/* Cтратегии инициализации скорости */
struct Fire_InitVelocity {
	inline void operator () (Particle *particle, double frameTime) {
		double dx = 0;//-0.01 + (rand() % 101) * 2.0 / 10000;
		double dy = 0.1 + (rand() % 101) * 5.0 / 30000;
		particle -> Velocity = Vector3f(dx, dy, 0.0f);
	}
};

struct Smoke_InitVelocity {
	inline void operator () (Particle *particle, double frameTime) {
		double dx = -0.01 + (rand() % 101) * 10.0 / 100000;
		double dy = 0.005 + (rand() % 101) * 1.0 / 5000;
		particle -> Velocity = Vector3f(dx, dy, 0.0f);
	}
};

/* Стратегии обработки размера*/
struct Fire_ProcSize {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Size *= 0.995;
	}
};

struct Smoke_ProcSize {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Size *= 1.005;
		if (particle->Size.X > 3)
			particle -> Size = Vector3f(3,3,0);
	}
};

/* Стратегия обработки положения */
struct Fire_ProcPosition {
	inline void operator () (Particle *particle, double frameTime) {
		Vector3f jiggleVector((double)(50-rand()%100)*1.0/1000, 0.0f, 0.0f);
		jiggleVector += particle -> Velocity;
		jiggleVector *= frameTime;
		particle -> Position = particle -> Position + jiggleVector;

	}
};

struct Smoke_ProcPosition {
	inline void operator () (Particle *particle, double frameTime) {
		//Vector3f jiggleVector((double)(50-rand()%100)*1.0/1000, 0.0f, 0.0f);
		Vector3f jiggleVector = particle -> Velocity;
		jiggleVector *= frameTime;
		particle -> Position = particle -> Position + jiggleVector;

	}
};

/* Стратегии обработки времени жизни */
struct Fire_ProcLife {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Life = particle -> Life - 10;		
	}
};

struct Smoke_ProcLife {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Life = particle -> Life - 1;		
	}
};

/* Стратегиии обработки цвета */
struct Fire_ProcColor {
	inline void operator () (Particle *particle, double frameTime) {
		if (particle -> Life * 1.0 < 200) particle -> Color.Alpha = 1 - particle -> Life * 1.0 / 1000;
	}
};

struct Smoke_ProcColor {
	inline void operator () (Particle *particle, double frameTime) {
		particle -> Color.Alpha = 1 - particle -> Life * 1.0 / 1000;
	}
};

/* NullPolicy - пустая стратегия */
struct NullPolicy {
	inline void operator () (Particle *particle, double frameTime) {}
};

#endif